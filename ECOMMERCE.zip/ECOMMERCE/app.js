const wrapper = document.querySelector(".sliderWrapper");
const menuItems = document.querySelectorAll(".menuItem");
const searchInput = document.getElementById("searchInput");
const searchButton = document.getElementById("searchButton");
const productContainer = document.getElementById("productContainer");

const products = [
  {
    id: 1,
    title: "Air Force",
    price: 119,
    colors: [
      {
        code: "black",
        img: "./img/air.png",
      },
      {
        code: "darkblue",
        img: "./img/air2.png",
      },
    ],
  },
  {
    id: 2,
    title: "Air Jordan",
    price: 149,
    colors: [
      {
        code: "lightgray",
        img: "./img/jordan.png",
      },
      {
        code: "green",
        img: "./img/jordan2.png",
      },
    ],
  },
  {
    id: 3,
    title: "Blazer",
    price: 109,
    colors: [
      {
        code: "lightgray",
        img: "./img/blazer.png",
      },
      {
        code: "green",
        img: "./img/blazer2.png",
      },
    ],
  },
  {
    id: 4,
    title: "Crater",
    price: 129,
    colors: [
      {
        code: "black",
        img: "./img/crater.png",
      },
      {
        code: "lightgray",
        img: "./img/crater2.png",
      },
    ],
  },
  {
    id: 5,
    title: "Hippie",
    price: 99,
    colors: [
      {
        code: "gray",
        img: "./img/hippie.png",
      },
      {
        code: "black",
        img: "./img/hippie2.png",
      },
    ],
  },
];

let choosenProduct = products[0];

const currentProductImg = document.querySelector(".productImg");
const currentProductTitle = document.querySelector(".productTitle");
const currentProductPrice = document.querySelector(".productPrice");
const currentProductColors = document.querySelectorAll(".color");
const currentProductSizes = document.querySelectorAll(".size");

menuItems.forEach((item, index) => {
  item.addEventListener("click", () => {
    // Change the current slide
    wrapper.style.transform = `translateX(${-100 * index}vw)`;

    // Change the chosen product
    choosenProduct = products[index];

    // Change texts of currentProduct
    currentProductTitle.textContent = choosenProduct.title;
    currentProductPrice.textContent = "$" + choosenProduct.price;
    currentProductImg.src = choosenProduct.colors[0].img;

    // Assign new colors
    currentProductColors.forEach((color, index) => {
      color.style.backgroundColor = choosenProduct.colors[index].code;
    });
  });
});

currentProductColors.forEach((color, index) => {
  color.addEventListener("click", () => {
    currentProductImg.src = choosenProduct.colors[index].img;
  });
});

currentProductSizes.forEach((size, index) => {
  size.addEventListener("click", () => {
    currentProductSizes.forEach((size) => {
      size.style.backgroundColor = "white";
      size.style.color = "black";
    });
    size.style.backgroundColor = "black";
    size.style.color = "white";
  });
});

const productButton = document.querySelector(".productButton");
const cartPopup = document.querySelector(".cartPopup");
const cartItemsList = document.querySelector(".cartItems");
const closeCart = document.querySelector(".closeCart");
const checkoutButton = document.querySelector(".checkoutButton");
const payment = document.querySelector(".payment");
const closePayment = document.querySelector(".close");

// New global cart array
let cart = [];

// Modify productButton functionality to add product to cart instead of showing payment
productButton.addEventListener("click", () => {
  // Add current product to cart
  cart.push(choosenProduct);
  updateCartPopup();
  cartPopup.style.display = "flex";
});

// Function to update cart popup content
function updateCartPopup() {
  cartItemsList.innerHTML = "";
  cart.forEach((item, index) => {
    let li = document.createElement("li");
    li.innerHTML = `${item.title} - $${item.price} 
      <button class="removeItem" data-index="${index}">Remove</button>`;
    cartItemsList.appendChild(li);
  });
}

// Remove item functionality
cartItemsList.addEventListener("click", (e) => {
  if (e.target.classList.contains("removeItem")) {
    const idx = parseInt(e.target.getAttribute("data-index"));
    cart.splice(idx, 1);
    updateCartPopup();
  }
});

// Close cart popup when "X" is clicked
closeCart.addEventListener("click", () => {
  cartPopup.style.display = "none";
});

// Show payment modal when checkout button is clicked
checkoutButton.addEventListener("click", () => {
  cartPopup.style.display = "none";
  payment.style.display = "flex";
});

// Close payment modal when "X" is clicked
closePayment.addEventListener("click", () => {
  payment.style.display = "none";
});

// Login/Signup Modal
function showAuthModal() {
  document.getElementById('authModal').style.display = 'block';
}

function closeAuthModal() {
  document.getElementById('authModal').style.display = 'none';
}

document.querySelector('.closeAuth').addEventListener('click', closeAuthModal);

window.addEventListener('click', function(event) {
  if (event.target == document.getElementById('authModal')) {
    closeAuthModal();
  }
});

// Price Slider
const priceSlider = document.querySelector(".priceSlider input[type='range']");
const priceValue = document.querySelector(".priceSlider .priceValue");

priceSlider.addEventListener("input", () => {
  priceValue.textContent = `$${priceSlider.value}`;
  filterProductsByPrice(priceSlider.value);
});

function filterProductsByPrice(maxPrice) {
  const filteredProducts = products.filter(product => product.price <= maxPrice);
  updateProductDisplay(filteredProducts);
}

// Email Notification
const emailNotification = document.querySelector(".emailNotification");
const closeEmailNotification = document.querySelector(".closeEmailNotification");

function showEmailNotification() {
  emailNotification.style.display = "flex";
}

closeEmailNotification.addEventListener("click", () => {
  emailNotification.style.display = "none";
});

// Simulate email notification on checkout
checkoutButton.addEventListener("click", () => {
  payment.style.display = "none";
  showEmailNotification();
});

// Search Functionality
searchButton.addEventListener("click", () => {
  const searchTerm = searchInput.value.toLowerCase();
  const filteredProducts = products.filter(product => product.title.toLowerCase().includes(searchTerm));
  updateProductDisplay(filteredProducts);
});

searchInput.addEventListener("input", () => {
  const searchTerm = searchInput.value.toLowerCase();
  const filteredProducts = products.filter(product => product.title.toLowerCase().includes(searchTerm));
  updateProductDisplay(filteredProducts);
});

function updateProductDisplay(filteredProducts) {
  productContainer.innerHTML = "";
  filteredProducts.forEach(product => {
    const productElement = document.createElement("div");
    productElement.classList.add("sliderItem");
    productElement.innerHTML = `
      <img src="${product.colors[0].img}" alt="${product.title}" class="sliderImg">
      <div class="sliderBg"></div>
      <h1 class="sliderTitle">${product.title}<br> NEW<br> SEASON</h1>
      <h2 class="sliderPrice">$${product.price}</h2>
      <a href="#product">
        <button class="buyButton">BUY NOW!</button>
      </a>
    `;
    productContainer.appendChild(productElement);
  });
}

// Initial display of all products
updateProductDisplay(products);